user_collection {
	user_id: "alksdjlajsdaksd",
	last_online: 12312313,

	history: [
	{
		id:"137894",
		lastVisitTime:1480091434261.978,
		title:"",
		typedCount:0,
		url:"http://weibo.com/cottonty1990/home?leftnav=1&pids=plc_main",
		visitCount:2
	},
	{

	}],

	cookies: [
	{
		domain:"developers.google.com",
		expirationDate:1794719157.325055,
		hostOnly:true,
		httpOnly:false,
		name:"devsite_dark_code",
		path:"/analytics/devguides/collection/analyticsjs",
		sameSite:"no_restriction",
		secure:false,
		session:true,
		storeId:"0",
		value:"off"
	},
	{

	}],

	forms: [{ 	 
		baseURI: 'file:///Users/COTTON/cse509/test.html?',
		inputs: [{ 
			id: 'input2', 
			value: 'lkajsda' 
		},
		{ 
			id: 'input3', 
			value: 'zxczxc' 
		}] 		
	},
	{

	}]
}